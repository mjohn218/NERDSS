/* \file nerdss.cpp
 * \brief Main function for simulation.
 *
 * ## TODO:
 *  - Change freelist from unordered list of relative iface indices to ordered list of absolute indices.
 *    really speed up evaluate_binding_pair
 *  - Write species tracker (tracks connectivity)
 *  - Compress reflect_traj_complex_rad_rot, reflect_traj_check_span, reflect_traj_rad_rot_nocheck
 */
#include "classes/class_Vector.hpp"
#include "boundary_conditions/reflect_functions.hpp"
#include "io/io.hpp"
#include "math/constants.hpp"
#include "math/matrix.hpp"
#include "math/rand_gsl.hpp"
#include "parser/parser_functions.hpp"
#include "reactions/association/association.hpp"
#include "reactions/bimolecular/bimolecular_reactions.hpp"
#include "reactions/implicitlipid/implicitlipid_reactions.hpp"
#include "reactions/shared_reaction_functions.hpp"
#include "reactions/unimolecular/unimolecular_reactions.hpp"
#include "system_setup/system_setup.hpp"
#include "trajectory_functions/trajectory_functions.hpp"

#include <chrono>
#include <cstring>
#include <iomanip>
#include <random>
#include <sstream>
#include <cmath>
using namespace std;

gsl_rng* r; /* global generator */

// easier to read timer
using MDTimer = std::chrono::system_clock;
using timeDuration = std::chrono::duration<double, std::chrono::seconds>;

/* INITIALIZE GLOBALS */
long long randNum = 0;
unsigned long totMatches = 0;

int calculateCentreAndRadius(const vector<double> &p1,const vector<double> &p2,
        const vector<double> &p3, const vector<double> &p4,
        vector<double> &centre, double &radius){
    double a = p1[0] - p2[0], b = p1[1] - p2[1], c = p1[2] - p2[2];
    double a1 = p3[0] - p4[0], b1 = p3[1] - p4[1], c1 = p3[2] - p4[2];
    double a2 = p2[0] - p3[0], b2 = p2[1] - p3[1], c2 = p2[2] - p3[2];
    double A = p1[0] * p1[0] - p2[0] * p2[0];
    double B = p1[1] * p1[1] - p2[1] * p2[1];
    double C = p1[2] * p1[2] - p2[2] * p2[2];
    double A1 = p3[0] * p3[0] - p4[0] * p4[0];
    double B1 = p3[1] * p3[1] - p4[1] * p4[1];
    double C1 = p3[2] * p3[2] - p4[2] * p4[2];
    double A2 = p2[0] * p2[0] - p3[0] * p3[0];
    double B2 = p2[1] * p2[1] - p3[1] * p3[1];
    double C2 = p2[2] * p2[2] - p3[2] * p3[2];
    double P = (A + B + C) /2;
    double Q = (A1 + B1 + C1) / 2;
    double R = (A2 + B2 + C2) / 2;

    // D是系数行列式，利用克拉默法则
    double D = a*b1*c2 + a2*b*c1 + c*a1*b2 - (a2*b1*c + a1*b*c2 + a*b2*c1);
    double Dx = P*b1*c2 + b*c1*R + c*Q*b2 - (c*b1*R + P*c1*b2 + Q*b*c2);
    double Dy = a*Q*c2 + P*c1*a2 + c*a1*R - (c*Q*a2 + a*c1*R + c2*P*a1);
    double Dz = a*b1*R + b*Q*a2 + P*a1*b2 - (a2*b1*P + a*Q*b2 + R*b*a1);

    if(D == 0){
        cerr << "四点共面" << endl;
        return -1;
    }else{
        centre.push_back(Dx/D);
        centre.push_back(Dy/D);
        centre.push_back(Dz/D);
        radius = sqrt((p1[0]-centre[0])*(p1[0]-centre[0]) +
                              (p1[1]-centre[1])*(p1[1]-centre[1]) +
                              (p1[2]-centre[2])*(p1[2]-centre[2]));
        return 0;
    }
}

bool onSphere(Molecule mol, double radius) {
    return abs(mol.comCoord.get_magnitude() - radius) < 1.0E-1;
}

int main(int argc, char* argv[])
{
    /* SIMULATION SETUP */
    // Get seed for random number generation
    // use random_device instead of time so that multiple jobs started at the same time have more unique seeds
    std::random_device rd {};
    unsigned seed { rd() };

    // get time point for total simulation time
    MDTimer::time_point totalTimeStart = MDTimer::now();

    /* SET UP SIMULATION LISTS */
    // Simulation species lists
    std::vector<MolTemplate> molTemplateList {}; // list of provided molecule templates

    // Reaction lists
    std::vector<ForwardRxn> forwardRxns {}; // list of forward reactions
    std::vector<BackRxn> backRxns {}; // list of back reactions (corresponding to forward reactions)
    std::vector<CreateDestructRxn> createDestructRxns {}; // list of creation and destruction reactions
    forwardRxns.reserve(10);
    backRxns.reserve(10);

    /* PARSE INPUT */
    Parameters params {};
    std::string paramFile {};

    // set up some output files
    // TODO: change these to open and close as needed
    std::string observablesFileName { "observables_time.dat" };
    std::string trajFileName { "trajectory.xyz" };
    std::string transitionFileName { "transition_matrix_time.dat" };
    std::string restartFileName { "new_restart.dat" };
    std::string addFileNameInput {}; // this is for restart with changed params or adding molecules and reactions
    std::string restartFileNameInput { "restart.dat" }; //if you read it in, allow it to have its own name.
    params.rank = -1; //for serial jobs, this impacts the name of the restart file.

    auto startTime = MDTimer::to_time_t(totalTimeStart);
    char charTime[24];
    std::cout << "\nStart date: ";
    if (0 < strftime(charTime, sizeof(charTime), "%F %T", std::localtime(&startTime)))
        std::cout << charTime << '\n';
    std::cout << "RNG Seed: " << seed << std::endl;

    //random generator
    const gsl_rng_type* T;
    T = gsl_rng_default;
    r = gsl_rng_alloc(T);
    gsl_rng_set(r, seed);

    /* SET UP SOME IMPORTANT VARIABLES */
    // 2D reaction probability tables
    std::vector<gsl_matrix*> survMatrices; // used in evaluate_binding_pair_com
    std::vector<gsl_matrix*> normMatrices; // idem
    std::vector<gsl_matrix*> pirMatrices; // idem
    double* tableIDs = new double[params.max2DRxns * 2]; // TODO: Change this?

    /* SET UP SYSTEM */
    std::map<std::string, int> observablesList;
    SimulVolume simulVolume {};
    std::vector<Molecule> moleculeList {}; // list of all molecules in the system
    std::vector<Complex> complexList {}; // list of all complexes in the system
    Membrane membraneObject; //class structure that contains boundary conditions, implicit lipid model.
    copyCounters counterArrays; // contains arrays tracking bound molecule pairs, and species copy nums.
    int implicitlipidIndex { 0 }; // implicit-lipid index, which is also stored in membraneObject.implicitlipidIndex.

    long long int simItr { 0 };

    // some variables used for parsing add.inp

    int numMolTemplateBeforeAdd { 0 }; // number of molTemp before add
    int numDoubleBeforeAdd { 0 }; // number of double complex before add
    int numForwardRxnBdeforeAdd { 0 }; //number of Forw React before add
    int numBackRxnBdeforeAdd { 0 }; //number of Back React before add
    int numCreatDestructRxnBdeforeAdd { 0 }; //num of creat and destruct react before add
    int tempLastStateIndexBeforeAdd { 0 }; // the last state index before add
    int tempLastStateIndexAfterAdd { 0 }; // the last state index after add
    int numStateAdd { 0 }; // num of added states
    int totalSpeciesNum { 0 }; //total species num after add
    init_association_events(counterArrays); //initialize event counters to zero. Restart will update any non-zero values.

    std::ifstream restartFileInput { restartFileNameInput };
    if (!restartFileInput) {
        std::cerr << "Error, could not find restart file, exiting...\n";
        exit(1);
    }

    read_restart(simItr, restartFileInput, params, simulVolume, moleculeList, complexList, molTemplateList, forwardRxns,
        backRxns, createDestructRxns, observablesList, membraneObject, counterArrays);
    restartFileInput.close();

    params.fromRestart = true;

    // initialize numberOfProteinEachState
    for (int tmpStateIndex = 0; tmpStateIndex < membraneObject.nStates; tmpStateIndex++) {
        membraneObject.numberOfProteinEachState.emplace_back(0);
    }

    //create water box for sphere boundary
    if (membraneObject.isSphere) {
        membraneObject.create_water_box();
        membraneObject.sphereVol = (4.0 * M_PI * pow(membraneObject.sphereR, 3.0)) / 3.0;
    }

    params.numTotalSpecies = RxnBase::totRxnSpecies;

    // set up some important parameters for implicit-lipid model;
    initialize_paramters_for_implicitlipid_model(implicitlipidIndex, params, forwardRxns, backRxns,
        moleculeList, molTemplateList, complexList, membraneObject);

    // initialize the starting copy number for each state
    initialize_states(moleculeList, molTemplateList, membraneObject);

    /* CREATE SIMULATION BOX CELLS */
    set_rMaxLimit(params, molTemplateList, forwardRxns, numDoubleBeforeAdd, numMolTemplateBeforeAdd);
    simulVolume.create_simulation_volume(params, membraneObject);
    simulVolume.update_memberMolLists(params, moleculeList, complexList, molTemplateList, membraneObject, simItr);


    if (membraneObject.implicitLipid == true)
        params.implicitLipid = true; //Created this parameter for convenience.
    for (auto& oneReaction : forwardRxns) {
        if (oneReaction.rxnType == ReactionType::uniMolStateChange) {
            params.hasUniMolStateChange = true;
            break;
        }
    }
    if (createDestructRxns.empty() == false) {
        params.hasCreationDestruction = true;
        params.isNonEQ = true;

        // set molTemp.canDestroy = ture
        for (auto& oneReaction : createDestructRxns) {
            if (oneReaction.rxnType == ReactionType::destruction) {
                molTemplateList[oneReaction.reactantMolList.at(0).molTypeIndex].canDestroy = true;
            }
        }
        for (auto& oneTemp : molTemplateList) {
            if (oneTemp.canDestroy == false) {
                oneTemp.monomerList.clear();
            }
        }
    }

    /* SETUP OUTPUT FILES */
    /*output files reporting bound pairs, and histogram of complex components*/

    // the variable params.numIfaces does not seem to be used anywhere for anything. It is also not correctly
    // initialized anywhere. during a restart, it is read in, but previous sims would not have set to proper value.

    char fnameProXYZ[100];
    sprintf(fnameProXYZ, "histogram_complexes_time.dat");
    std::ofstream assemblyfile(fnameProXYZ);
    sprintf(fnameProXYZ, "mono_dimer_time.dat");
    std::ofstream dimerfile(fnameProXYZ);
    sprintf(fnameProXYZ, "event_counters_time.dat");
    std::ofstream eventFile(fnameProXYZ);
    sprintf(fnameProXYZ, "bound_pair_time.dat");
    std::ofstream pairOutfile(fnameProXYZ);
    sprintf(fnameProXYZ, "copy_numbers_time.dat");
    std::ofstream speciesFile1(fnameProXYZ);

    int meanComplexSize { 0 };

    totalSpeciesNum = init_speciesFile(speciesFile1, counterArrays, molTemplateList, forwardRxns, params);
    init_counterCopyNums(counterArrays, moleculeList, complexList, molTemplateList, membraneObject, totalSpeciesNum, params); // works for default and restart

    write_all_species((simItr - params.itrRestartFrom) * params.timeStep * Constants::usToSeconds + params.timeRestartFrom, speciesFile1, counterArrays);

    init_print_dimers(dimerfile, params, molTemplateList); // works for default and restart
    init_NboundPairs(counterArrays, pairOutfile, params, molTemplateList, moleculeList); // initializes to zero, re-calculated for a restart!!
    write_NboundPairs(counterArrays, pairOutfile, simItr, params, moleculeList);
    print_dimers(complexList, dimerfile, simItr, params, molTemplateList);
    print_association_events(counterArrays, eventFile, simItr, params);
    //this will be wrong if there are no implicit lipids.
    //const int ILcopyIndex = moleculeList[implicitlipidIndex].interfaceList[0].index;

    int number_of_lipids = 0; //sum of all states of IL
    for (int i = 0; i < membraneObject.numberOfFreeLipidsEachState.size(); i++) {
        number_of_lipids += membraneObject.numberOfFreeLipidsEachState[i];
    }
    meanComplexSize = print_complex_hist(complexList, assemblyfile, simItr, params, molTemplateList, number_of_lipids);

    //set some parameters
    if (params.checkPoint == -1) {
        params.checkPoint = params.nItr / 10;
    }
    if (params.transitionWrite == -1) {
        params.transitionWrite = params.nItr / 10;
    }

    // set the excludeVolumeBoundList for each molTemplate according to the reaction list
    for (auto& oneReaction : forwardRxns) {
        if (oneReaction.excludeVolumeBound == true) {
            // this reaction declare that excludeVolumeBound, now add the partner's index to the excludeVolumeBoundList
            int react1MolIndex = oneReaction.reactantListNew[0].molTypeIndex;
            int react1InfIndex = oneReaction.reactantListNew[0].relIfaceIndex;
            int react1InfAbsIndex = oneReaction.reactantListNew[0].absIfaceIndex;
            int react2MolIndex = oneReaction.reactantListNew[1].molTypeIndex;
            int react2InfIndex = oneReaction.reactantListNew[1].relIfaceIndex;
            int react2InfAbsIndex = oneReaction.reactantListNew[1].absIfaceIndex;
            molTemplateList[react1MolIndex].interfaceList[react1InfIndex].excludeVolumeBoundList.push_back(react2MolIndex);
            molTemplateList[react2MolIndex].interfaceList[react2InfIndex].excludeVolumeBoundList.push_back(react1MolIndex);
            molTemplateList[react1MolIndex].interfaceList[react1InfIndex].excludeVolumeBoundIfaceList.push_back(react2InfIndex);
            molTemplateList[react2MolIndex].interfaceList[react2InfIndex].excludeVolumeBoundIfaceList.push_back(react1InfIndex);
            molTemplateList[react1MolIndex].interfaceList[react1InfIndex].excludeRadiusList.push_back(oneReaction.bindRadius);
            molTemplateList[react2MolIndex].interfaceList[react2InfIndex].excludeRadiusList.push_back(oneReaction.bindRadius);
            molTemplateList[react1MolIndex].interfaceList[react1InfIndex].excludeVolumeBoundReactList.push_back(oneReaction.relRxnIndex);
            molTemplateList[react2MolIndex].interfaceList[react2InfIndex].excludeVolumeBoundReactList.push_back(oneReaction.relRxnIndex);
            molTemplateList[react1MolIndex].excludeVolumeBound = true;
            molTemplateList[react2MolIndex].excludeVolumeBound = true;
        }
    }

    for (auto& oneComplex : complexList) {
        oneComplex.update_properties(moleculeList, molTemplateList);
    }

    Parameters::dt = params.timeStep;
    Parameters::lastUpdateTransition.resize(molTemplateList.size());




    ////////////////////////////////////////////////////////////////
    // hack the restart.dat file
    // calculate the center and radius of the sphereVol
    //std::ifstream coordsFile("4points.dat");
    //std::string coordsLine;
    std::vector<double> p1;
    std::vector<double> p2;
    std::vector<double> p3;
    std::vector<double> p4;
    /*
    getline(coordsFile, coordsLine);
    p1 = parse_input_array(coordsLine);
    p1[0] = p1[0] - membraneObject.waterBox.x / 2;
    p1[1] = p1[1] - membraneObject.waterBox.y / 2;
    p1[2] = p1[2] - membraneObject.waterBox.z / 2;
    getline(coordsFile, coordsLine);
    p2 = parse_input_array(coordsLine);
    p2[0] = p2[0] - membraneObject.waterBox.x / 2;
    p2[1] = p2[1] - membraneObject.waterBox.y / 2;
    p2[2] = p2[2] - membraneObject.waterBox.z / 2;
    getline(coordsFile, coordsLine);
    p3 = parse_input_array(coordsLine);
    p3[0] = p3[0] - membraneObject.waterBox.x / 2;
    p3[1] = p3[1] - membraneObject.waterBox.y / 2;
    p3[2] = p3[2] - membraneObject.waterBox.z / 2;
    getline(coordsFile, coordsLine);
    p4 = parse_input_array(coordsLine);
    p4[0] = p4[0] - membraneObject.waterBox.x / 2;
    p4[1] = p4[1] - membraneObject.waterBox.y / 2;
    p4[2] = p4[2] - membraneObject.waterBox.z / 2;
    coordsFile.close();
    */
    
    std::vector<double> oldCentre;
    double radius1, radius2;
    do {
        // random pick 4 mols and assign their coords to p1, p2, p3, p4
        int NA { 0 };
        NA = static_cast<int>(moleculeList.size());
        int randIntNum { static_cast<int>(1.0 * NA * rand_gsl()) };
        if (randIntNum == NA) {
            randIntNum = NA - 1;
        }
        p1.push_back(moleculeList[randIntNum].comCoord.x);
        p1.push_back(moleculeList[randIntNum].comCoord.y);
        p1.push_back(moleculeList[randIntNum].comCoord.z);

        randIntNum = static_cast<int>(1.0 * NA * rand_gsl());
        if (randIntNum == NA) {
            randIntNum = NA - 1;
        }
        p2.push_back(moleculeList[randIntNum].comCoord.x);
        p2.push_back(moleculeList[randIntNum].comCoord.y);
        p2.push_back(moleculeList[randIntNum].comCoord.z);

        randIntNum = static_cast<int>(1.0 * NA * rand_gsl());
        if (randIntNum == NA) {
            randIntNum = NA - 1;
        }
        p3.push_back(moleculeList[randIntNum].comCoord.x);
        p3.push_back(moleculeList[randIntNum].comCoord.y);
        p3.push_back(moleculeList[randIntNum].comCoord.z);

        randIntNum = static_cast<int>(1.0 * NA * rand_gsl());
        if (randIntNum == NA) {
            randIntNum = NA - 1;
        }
        p4.push_back(moleculeList[randIntNum].comCoord.x);
        p4.push_back(moleculeList[randIntNum].comCoord.y);
        p4.push_back(moleculeList[randIntNum].comCoord.z);

        calculateCentreAndRadius(p1, p2, p3, p4, oldCentre, radius1);

        randIntNum = static_cast<int>(1.0 * NA * rand_gsl());
        if (randIntNum == NA) {
            randIntNum = NA - 1;
        }
        p1.push_back(moleculeList[randIntNum].comCoord.x);
        p1.push_back(moleculeList[randIntNum].comCoord.y);
        p1.push_back(moleculeList[randIntNum].comCoord.z);

        randIntNum = static_cast<int>(1.0 * NA * rand_gsl());
        if (randIntNum == NA) {
            randIntNum = NA - 1;
        }
        p2.push_back(moleculeList[randIntNum].comCoord.x);
        p2.push_back(moleculeList[randIntNum].comCoord.y);
        p2.push_back(moleculeList[randIntNum].comCoord.z);

        randIntNum = static_cast<int>(1.0 * NA * rand_gsl());
        if (randIntNum == NA) {
            randIntNum = NA - 1;
        }
        p3.push_back(moleculeList[randIntNum].comCoord.x);
        p3.push_back(moleculeList[randIntNum].comCoord.y);
        p3.push_back(moleculeList[randIntNum].comCoord.z);

        randIntNum = static_cast<int>(1.0 * NA * rand_gsl());
        if (randIntNum == NA) {
            randIntNum = NA - 1;
        }
        p4.push_back(moleculeList[randIntNum].comCoord.x);
        p4.push_back(moleculeList[randIntNum].comCoord.y);
        p4.push_back(moleculeList[randIntNum].comCoord.z);

        calculateCentreAndRadius(p1, p2, p3, p4, oldCentre, radius2);
    }
    while(abs(radius1 - radius2) > 1E-1);

    // move the coordinates of all COMs and interfaces in the system
    std::vector<double> newCentre {0.0, 0.0, 0.0};
    Vector transVec {};
    transVec.x = newCentre[0] - oldCentre[0];
    transVec.y = newCentre[1] - oldCentre[1];
    transVec.z = newCentre[2] - oldCentre[2];
    
    for(auto & mol : moleculeList){
        if (complexList[mol.myComIndex].isEmpty == false && mol.isEmpty == false) {
            mol.update_association_coords(transVec);
            update_complex_tmp_com_crds(complexList[mol.myComIndex], moleculeList);
            mol.comCoord = mol.tmpComCoord;
            for (unsigned int i { 0 }; i < mol.interfaceList.size(); ++i)
                mol.interfaceList[i].coord = mol.tmpICoords[i];
            mol.clear_tmp_association_coords();
            complexList[mol.myComIndex].update_properties(moleculeList, molTemplateList);
        }
    }
    // print distance to center of each molecule
    int count {0};
    for(auto & mol : moleculeList){
        if(abs(radius2 - mol.comCoord.get_magnitude()) > 1E-1){
            count ++;
        }
    }
    cout <<">1E-1: "<<count-1<< endl;

    // delete the molecules that are not on the sphere
    for(auto & mol : moleculeList){
        if (complexList[mol.myComIndex].isEmpty == false && mol.isEmpty == false && mol.isImplicitLipid == false &&
            onSphere(mol, radius2) == false){
            // decrement the copy number array for everything in complex
            for (auto& memMol : complexList[mol.myComIndex].memberList) {
                for (auto& iface : moleculeList[memMol].interfaceList) {
                    --counterArrays.copyNumSpecies[iface.index];
                }
                for (auto itr = simulVolume.subCellList[moleculeList[memMol].mySubVolIndex].memberMolList.begin(); itr != simulVolume.subCellList[moleculeList[memMol].mySubVolIndex].memberMolList.end(); ++itr) {
                    if (*itr == moleculeList[memMol].index) {
                        simulVolume.subCellList[moleculeList[memMol].mySubVolIndex].memberMolList.erase(itr);
                        break;
                    }
                }
                moleculeList[memMol].mySubVolIndex = -1;
            }
            
            if(complexList[mol.myComIndex].memberList.size() == 1){
                // update the oneTemp.monomerList if it is necessary
                MolTemplate& oneTemp { molTemplateList[mol.molTypeIndex] };
                if (oneTemp.canDestroy == true) {
                    std::vector<int>& oneList { oneTemp.monomerList };
                    std::vector<int>::iterator result { std::find(std::begin(oneList), std::end(oneList), mol.index) };
                    if (result != std::end(oneList)) {
                        oneList.erase(result);
                    }
                }
            } else {
                for (auto oneDissociate : complexList[mol.myComIndex].memberList) {
                    // update the countArrays.bindPairList
                    for (auto& oneSpecie : counterArrays.bindPairList) {
                        std::vector<int>& oneList { oneSpecie };
                        std::vector<int>::iterator result { std::find(std::begin(oneList), std::end(oneList), oneDissociate) };
                        if (result != std::end(oneList)) {
                            oneList.erase(result);
                        }
                    }
                }
            }
            complexList[mol.myComIndex].destroy(moleculeList, complexList);
        }
    }
    write_pdb(simItr, simItr, params, moleculeList, molTemplateList, membraneObject);
    write_NboundPairs(counterArrays, pairOutfile, simItr, params, moleculeList);
    print_dimers(complexList, dimerfile, simItr, params, molTemplateList);
    print_association_events(counterArrays, eventFile, simItr, params);
    number_of_lipids = 0; //sum of all states of IL
    for (int i = 0; i < membraneObject.numberOfFreeLipidsEachState.size(); i++) {
        number_of_lipids += membraneObject.numberOfFreeLipidsEachState[i];
    }
    meanComplexSize = print_complex_hist(complexList, assemblyfile, simItr, params, molTemplateList, number_of_lipids);
    write_all_species((simItr - params.itrRestartFrom) * params.timeStep * Constants::usToSeconds + params.timeRestartFrom, speciesFile1, counterArrays);
    
    //remove the empty complexes
    //first remove the empty complexes in the tail
    while (complexList.back().isEmpty == true) {
        int tempIndex { complexList.back().index }; // the removed complex's index
        complexList.pop_back();
        //update Complex::emptyComList
        for (auto& tempEmpty : Complex::emptyComList) {
            if (tempEmpty == tempIndex) {
                tempEmpty = Complex::emptyComList.back();
                Complex::emptyComList.pop_back();
                break;
            }
        }
    }

    // put the last non-empty complex in the list to the non-last empty slot
    while (Complex::emptyComList.empty() == false) {
        int slotIndex { Complex::emptyComList.back() };
        int previousIndex { complexList.back().index };

        complexList[slotIndex] = complexList.back();
        complexList[slotIndex].index = slotIndex;
        complexList.pop_back();

        // change the mol.myComIndex with previousIndex to slotIndex
        for (auto mp : complexList[slotIndex].memberList) {
            moleculeList[mp].myComIndex = slotIndex;
        }

        //update Complex::emptyComList
        Complex::emptyComList.pop_back();

        //remove the empty complexes in the tail
        while (complexList.back().isEmpty == true) {
            int tempIndex { complexList.back().index }; // the removed complex's index
            complexList.pop_back();
            //update Complex::emptyComList
            for (auto& tempEmpty : Complex::emptyComList) {
                if (tempEmpty == tempIndex) {
                    tempEmpty = Complex::emptyComList.back();
                    Complex::emptyComList.pop_back();
                    break;
                }
            }
        }
    }

    //------------------------------------------------------------------------------------
    //remove the empty molecules
    //first remove the empty molecule in the tail
    while (moleculeList.back().isEmpty == true) {
        int tempIndex { moleculeList.back().index }; // the removed molecule's index
        moleculeList.pop_back();
        //update Molecule::emptyMolList
        for (auto& tempEmpty : Molecule::emptyMolList) {
            if (tempEmpty == tempIndex) {
                tempEmpty = Molecule::emptyMolList.back();
                Molecule::emptyMolList.pop_back();
                break;
            }
        }
    }

    // put the last non-empty molecule in the list to the non-last empty slot
    while (Molecule::emptyMolList.empty() == false) {
        int slotIndex { Molecule::emptyMolList.back() };
        int previousIndex { moleculeList.back().index };

        moleculeList[slotIndex] = moleculeList.back();
        moleculeList[slotIndex].index = slotIndex;
        moleculeList.pop_back();

        // change the mol.index with previousIndex to slotIndex, include complex.memberlist; interface.interaction.partnerIndex;mol.bndpartner
        int tmpComIndex { moleculeList[slotIndex].myComIndex };
        for (auto& tmpMember : complexList[tmpComIndex].memberList) {
            if (tmpMember == previousIndex)
                tmpMember = slotIndex;
        }

        for (auto& tmpPartner : moleculeList[slotIndex].bndpartner) {
            for (auto& partner : moleculeList[tmpPartner].bndpartner) {
                if (partner == previousIndex)
                    partner = slotIndex;
            }
            for (auto& tmpIface : moleculeList[tmpPartner].interfaceList) {
                if (tmpIface.interaction.partnerIndex == previousIndex)
                    tmpIface.interaction.partnerIndex = slotIndex;
            }
        }

        // update the oneTemp.monomerList if it is necessary
        MolTemplate& oneTemp { molTemplateList[moleculeList[slotIndex].molTypeIndex] };
        if (oneTemp.canDestroy == true) {
            std::vector<int>& oneList { oneTemp.monomerList };
            std::vector<int>::iterator result { std::find(std::begin(oneList), std::end(oneList), previousIndex) }; //check whether previousIndex in oneTemp.monomerList
            if (result != std::end(oneList)) {
                oneList.erase(result);
                oneList.emplace_back(slotIndex);
            }
        }

        // update the countArrays.bindPairList
        // check whether previousIndex in countArrays.bindPairList
        for (auto& oneSpecie : counterArrays.bindPairList) {
            for (auto& oneIndex : oneSpecie) {
                if (oneIndex == previousIndex) {
                    oneIndex = slotIndex;
                }
            }
        }

        //update Molecule::emptyMolList
        Molecule::emptyMolList.pop_back();

        //remove the empty molecules in the tail
        while (moleculeList.back().isEmpty == true) {
            int tempIndex { moleculeList.back().index }; // the removed molecule's index
            moleculeList.pop_back();
            //update Molecule::emptyMolList
            for (auto& tempEmpty : Molecule::emptyMolList) {
                if (tempEmpty == tempIndex) {
                    tempEmpty = Molecule::emptyMolList.back();
                    Molecule::emptyMolList.pop_back();
                    break;
                }
            }
        }
    }
    write_pdb(simItr, simItr, params, moleculeList, molTemplateList, membraneObject);
    write_NboundPairs(counterArrays, pairOutfile, simItr, params, moleculeList);
    print_dimers(complexList, dimerfile, simItr, params, molTemplateList);
    print_association_events(counterArrays, eventFile, simItr, params);
    number_of_lipids = 0; //sum of all states of IL
    for (int i = 0; i < membraneObject.numberOfFreeLipidsEachState.size(); i++) {
        number_of_lipids += membraneObject.numberOfFreeLipidsEachState[i];
    }
    meanComplexSize = print_complex_hist(complexList, assemblyfile, simItr, params, molTemplateList, number_of_lipids);
    write_all_species((simItr - params.itrRestartFrom) * params.timeStep * Constants::usToSeconds + params.timeRestartFrom, speciesFile1, counterArrays);
    
    // change the state of each molecule to be bound with membrane
    // add link to surface for the molecule
    for (auto & mol : moleculeList) {
        if (mol.isImplicitLipid == true) {
            continue;
        }
        mol.linksToSurface++;
        // update complexes
        complexList[mol.myComIndex].iLipidIndex = implicitlipidIndex; // index in molecule list of the implicit lipid.
        complexList[mol.myComIndex].linksToSurface++;
        complexList[mol.myComIndex].update_properties(moleculeList, molTemplateList); // recalculate the properties of the first complex
        complexList[mol.myComIndex].D.z = 0.0; // maybe redundant, since we can use linksToSurface > 0
        complexList[mol.myComIndex].OnSurface = true; // maybe redundant, since we can use linksToSurface > 0
        /*Clear implicit lipid properties*/
        complexList[moleculeList[implicitlipidIndex].myComIndex].memberList.clear();
        complexList[moleculeList[implicitlipidIndex].myComIndex].memberList.push_back(implicitlipidIndex);
        complexList[moleculeList[implicitlipidIndex].myComIndex].update_properties(moleculeList, molTemplateList); // recalculate the properties of the second complex
        // update Molecule interface statuses
        // index of membrane site is 0
        mol.interfaceList[0].interaction.partnerIndex = implicitlipidIndex;
        mol.interfaceList[0].interaction.partnerIfaceIndex = 0;
        // currRxn: gag (molTypeIndex is 0) is 0; pol (molTypeIndex is 1) is 1
        if (forwardRxns[mol.molTypeIndex - 1].isReversible) {
            mol.interfaceList[0].interaction.conjBackRxn = forwardRxns[mol.molTypeIndex - 1].conjBackRxnIndex;
        }

        mol.interfaceList[0].isBound = true;
        mol.interfaceList[0].index = forwardRxns[mol.molTypeIndex - 1].productListNew[0].absIfaceIndex;

        // add to the list of bound interfaces and remove from the list of free interfaces
        mol.bndlist.push_back(0);
        mol.bndpartner.push_back(implicitlipidIndex);
        {
            size_t tmpItr { 0 };
            for (unsigned i { 0 }; i < mol.freelist.size(); ++i) {
                if (mol.freelist[i] == 0)
                    tmpItr = i;
            }
            mol.freelist[tmpItr] = mol.freelist.back();
            mol.freelist.pop_back();
        }
        // update the number of bound species
        update_Nboundpairs(mol.molTypeIndex, moleculeList[implicitlipidIndex].molTypeIndex, 1, params,
            counterArrays);

        //Update species copy numbers
        counterArrays.copyNumSpecies[forwardRxns[mol.molTypeIndex - 1].reactantListNew[0].absIfaceIndex] -= 1; // decrement ifaceIndex1
        counterArrays.copyNumSpecies[forwardRxns[mol.molTypeIndex - 1].reactantListNew[1].absIfaceIndex] -= 1; // decrement ifaceIndex2
        counterArrays.copyNumSpecies[forwardRxns[mol.molTypeIndex - 1].productListNew[0].absIfaceIndex] += 1; // increment product state
        RxnIface implicitLipidState {};
        const auto& implicitLipidStateList = molTemplateList[moleculeList[membraneObject.implicitlipidIndex].molTypeIndex].interfaceList[0].stateList;
        if (molTemplateList[forwardRxns[mol.molTypeIndex - 1].reactantListNew[1].molTypeIndex].isImplicitLipid == true) {
            implicitLipidState = forwardRxns[mol.molTypeIndex - 1].reactantListNew[1];
        } else {
            implicitLipidState = forwardRxns[mol.molTypeIndex - 1].reactantListNew[0];
        }
        int relStateIndex { -1 };
        for (auto& state : implicitLipidStateList) {
            if (state.index == implicitLipidState.absIfaceIndex) {
                relStateIndex = static_cast<int>(&state - &implicitLipidStateList[0]);
                break;
            }
        }
        membraneObject.numberOfFreeLipidsEachState[relStateIndex] -= 1;
    }
    write_pdb(simItr, simItr, params, moleculeList, molTemplateList, membraneObject);
    write_NboundPairs(counterArrays, pairOutfile, simItr, params, moleculeList);
    print_dimers(complexList, dimerfile, simItr, params, molTemplateList);
    print_association_events(counterArrays, eventFile, simItr, params);
    number_of_lipids = 0; //sum of all states of IL
    for (int i = 0; i < membraneObject.numberOfFreeLipidsEachState.size(); i++) {
        number_of_lipids += membraneObject.numberOfFreeLipidsEachState[i];
    }
    meanComplexSize = print_complex_hist(complexList, assemblyfile, simItr, params, molTemplateList, number_of_lipids);
    write_all_species((simItr - params.itrRestartFrom) * params.timeStep * Constants::usToSeconds + params.timeRestartFrom, speciesFile1, counterArrays);
    

    // change the box to sphere
    membraneObject.isBox = false;
    membraneObject.isSphere = true;
    membraneObject.sphereR = radius2 + 2.0 + 0.01;
    if (membraneObject.isSphere) {
        membraneObject.create_water_box();
        membraneObject.sphereVol = (4.0 * M_PI * pow(membraneObject.sphereR, 3.0)) / 3.0;
    }
    set_rMaxLimit(params, molTemplateList, forwardRxns, numDoubleBeforeAdd, numMolTemplateBeforeAdd);
    simulVolume.create_simulation_volume(params, membraneObject);
    simulVolume.update_memberMolLists(params, moleculeList, complexList, molTemplateList, membraneObject, simItr);

    // modify the parms
    // system parms
    params.nItr = 10000000000;
    params.timeStep = 0.2;
    params.overlapSepLimit = 2.3;
    params.timeWrite = 25000;
    params.trajWrite = 25000000;
    params.restartWrite = 25000;
    params.pdbWrite = 25000;
    params.checkPoint = 25000;
    params.scaleMaxDisplace = 10.0;
    // reaction parms
    // gag(pol) + IL
    // index = [0, 1]
    vector<int> reactionSet{0, 1};
    for (auto i : reactionSet) {
        forwardRxns[i].bindRadius = 1.0;
        forwardRxns[i].length3Dto2D = 2.0 * forwardRxns[i].bindRadius;
        forwardRxns[i].rateList[0].rate = 1.0;
        backRxns[i].rateList[0].rate = 0.61;
    }

    // gag(pol) + gag(pol) dimer
    // index = [2, 3, 4]
    vector<int> reactionSetDimer{2, 3, 4};
    for (auto i : reactionSetDimer) {
        forwardRxns[i].length3Dto2D = 10.0;
        forwardRxns[i].rateList[0].rate = 0.1;
        backRxns[i].rateList[0].rate = 0.135;
    }

    // gag(pol) + gag(pol) hexamer
    // index = [5, 6, 7, 8]
    vector<int> reactionSetHexamer{5, 6, 7, 8};
    for (auto i : reactionSetHexamer) {
        forwardRxns[i].length3Dto2D = 10.0;
        forwardRxns[i].rateList[0].rate = 0.1;
        backRxns[i].rateList[0].rate = 54.51;
    }

    // ref-ref
    vector<int> reactionSetRef{9, 10, 11};
    for (auto i : reactionSetRef) {
        forwardRxns[i].bindRadius = 2.5;
    }

    // create gag(pol)
    vector<int> reactionSetCreate{0, 1};
    for (auto i : reactionSetCreate) {
        createDestructRxns[i].rateList[0].rate = 0.0;
    }

    ////////////////////////////////////////////////////////////////

    std::ofstream distanceFile { "distanceOfMembraneSitetoCenter.dat"};
    for(auto mol : moleculeList){
        if(mol.isImplicitLipid){
            continue;
        }
        else {
            double distance {mol.comCoord.get_magnitude() - 65};
            distanceFile << distance << endl;
        }
    }
    distanceFile.close();


    std::ofstream restartFile { restartFileName, std::ios::out };
    write_restart(simItr, restartFile, params, simulVolume, moleculeList, complexList, molTemplateList,
        forwardRxns, backRxns, createDestructRxns, observablesList, membraneObject, counterArrays);
    restartFile.close();

    write_pdb(simItr, simItr, params, moleculeList, molTemplateList, membraneObject);
    write_NboundPairs(counterArrays, pairOutfile, simItr, params, moleculeList);
    print_dimers(complexList, dimerfile, simItr, params, molTemplateList);
    print_association_events(counterArrays, eventFile, simItr, params);
    number_of_lipids = 0; //sum of all states of IL
    for (int i = 0; i < membraneObject.numberOfFreeLipidsEachState.size(); i++) {
        number_of_lipids += membraneObject.numberOfFreeLipidsEachState[i];
    }
    meanComplexSize = print_complex_hist(complexList, assemblyfile, simItr, params, molTemplateList, number_of_lipids);
    write_all_species((simItr - params.itrRestartFrom) * params.timeStep * Constants::usToSeconds + params.timeRestartFrom, speciesFile1, counterArrays);
    
    gsl_rng_free(r);
    return 0;
} // end main
