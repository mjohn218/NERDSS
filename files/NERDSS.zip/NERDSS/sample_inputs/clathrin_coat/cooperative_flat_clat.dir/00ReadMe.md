Example simulation of flat clathrin sheet formation in solution, featuring cooperativity.

- Biases against monomer-monomer interactions by increasing the rates for monomer - non-monomer and non-monomer - non-monomer interactions by a factor of 10
  - monomer - monomer: 0.0166 nm<sup>3</sup>/μs
  - monomer - non-monomer: 0.166 nm<sup>3</sup>/μs
  - non-monomer - non-monomer: 1.66 nm<sup>3</sup>/μs


for distinct clathrin leg sites, multiply rates by 2.