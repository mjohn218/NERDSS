#include "reactions/association/association.hpp"

bool areParallel(const double& angle)
{
    return angle == M_PI || angle == 0;
}
